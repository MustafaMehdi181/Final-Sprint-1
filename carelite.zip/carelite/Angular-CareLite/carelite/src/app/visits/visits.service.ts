// src/app/visits/visits.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Visit {
  visitId?: number;
  patientId: number;
  doctorId: number;
  visitTypeId: number;
  duration: string;
  visitDate: string;   // ISO string format
  doctorNotes: string;
}

@Injectable({ providedIn: 'root' })
export class VisitsService {
  private apiUrl = 'https://localhost:5001/api/Visits';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Visit[]> {
    return this.http.get<Visit[]>(this.apiUrl);
  }

  add(visit: Visit): Observable<any> {
    return this.http.post(this.apiUrl, visit);
  }

  update(visit: Visit): Observable<any> {
    return this.http.put(`${this.apiUrl}/${visit.visitId}`, visit);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
