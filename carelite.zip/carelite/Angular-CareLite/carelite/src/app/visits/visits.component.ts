// src/app/visits/visits.component.ts
import { Component, OnInit } from '@angular/core';
import { VisitsService, Visit } from './visits.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';


@Component({
  selector: 'app-visits',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './visits.html'
})
export class VisitsComponent implements OnInit {
  visits: Visit[] = [];
  newVisit: Visit = {
    patientId: 0,
    doctorId: 0,
    visitTypeId: 0,
    duration: '',
    visitDate: new Date().toISOString().substring(0, 10), // default today
    doctorNotes: ''
  };

  constructor(private visitsService: VisitsService) {}

  ngOnInit() {
    this.loadVisits();
  }

  async loadVisits() {
    try {
      const result = await firstValueFrom(this.visitsService.getAll());
      this.visits = result ?? [];
    } catch (err) {
      console.error('Failed to load visits:', err);
    }
  }

  async addVisit() {
    try {
      await firstValueFrom(this.visitsService.add(this.newVisit));
      this.newVisit = {
        patientId: 0,
        doctorId: 0,
        visitTypeId: 0,
        duration: '',
        visitDate: new Date().toISOString().substring(0, 10),
        doctorNotes: ''
      };
      this.loadVisits();
    } catch (err) {
      console.error('Failed to add visit:', err);
    }
  }

  async updateVisit(visit: Visit) {
    if (!visit.visitId) return;
    try {
      await firstValueFrom(this.visitsService.update(visit));
      this.loadVisits();
    } catch (err) {
      console.error('Failed to update visit:', err);
    }
  }

  async deleteVisit(id: number) {
    try {
      await firstValueFrom(this.visitsService.delete(id));
      this.loadVisits();
    } catch (err) {
      console.error('Failed to delete visit:', err);
    }
  }
}
