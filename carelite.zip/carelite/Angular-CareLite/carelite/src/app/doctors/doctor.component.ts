import { Component, OnInit } from '@angular/core';
import { DoctorsService , Doctor } from './doctor.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-doctors',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './doctor.component.html'
})
export class DoctorsComponent implements OnInit {
  doctors: Doctor[] = [];
  newDoctor: Doctor = { doctorName: '', doctorSpecialty: '' };

  constructor(private doctorService: DoctorsService) {}

  ngOnInit() {
    this.loadDoctors();
  }

  async loadDoctors() {
    try {
      const result = await firstValueFrom(this.doctorService.getAll());
      this.doctors = result ?? [];
    } catch (err) {
      console.error('Failed to load doctors:', err);
    }
  }

  async addDoctor() {
    if (!this.newDoctor.doctorName || !this.newDoctor.doctorSpecialty) return;
    try {
      await firstValueFrom(this.doctorService.add(this.newDoctor));
      this.newDoctor = { doctorName: '', doctorSpecialty: '' };
      this.loadDoctors();
    } catch (err) {
      console.error('Failed to add doctor:', err);
    }
  }

  async updateDoctor(doc: Doctor) {
    if (!doc.doctorId) return;
    try {
      await firstValueFrom(this.doctorService.update(doc));
      this.loadDoctors();
    } catch (err) {
      console.error('Failed to update doctor:', err);
    }
  }

  async deleteDoctor(id: number) {
    try {
      await firstValueFrom(this.doctorService.delete(id));
      this.loadDoctors();
    } catch (err) {
      console.error('Failed to delete doctor:', err);
    }
  }
}
