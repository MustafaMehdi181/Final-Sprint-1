// src/app/doctors/doctors.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Doctor {
  doctorId?: number;
  doctorName: string;
  doctorSpecialty: string;
}

@Injectable({ providedIn: 'root' })
export class DoctorsService {
  private apiUrl = 'https://localhost:5001/api/Doctors';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(this.apiUrl);
  }

  add(doctor: Doctor): Observable<any> {
    return this.http.post(this.apiUrl, doctor);
  }

  update(doctor: Doctor): Observable<any> {
    return this.http.put(`${this.apiUrl}/${doctor.doctorId}`, doctor);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
