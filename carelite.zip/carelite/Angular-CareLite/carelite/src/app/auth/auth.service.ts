import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environment/environemnt';

// Models
export interface LoginModel {
  email: string;
  passwords: string;
}

export interface RegisterModel {
  email: string;
  passwords: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = `${environment.apiUrl}/User`;

  constructor(private http: HttpClient) {}

  // 🔹 Login returns plain text response from backend
  login(model: LoginModel): Observable<string> {
  return this.http.post<string>(`${this.baseUrl}/login`, model, {
    responseType: 'text' as 'json'  // 👈 tells Angular to expect plain text
  });
}

  // 🔹 Register new user
  register(model: RegisterModel): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, model);
  }
}
