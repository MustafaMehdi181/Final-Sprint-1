// src/app/patients/patients.component.ts
import { Component, OnInit } from '@angular/core';
import { PatientsService, Patient } from './patients.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-patients',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './patient.component.html'
})
export class PatientsComponent implements OnInit {
  patients: Patient[] = [];
  newPatient: Patient = { patientName: '', patientPhone: '' };

  constructor(private patientsService: PatientsService) {}

  ngOnInit() {
    this.loadPatients();
  }

  async loadPatients() {
    try {
      const result = await firstValueFrom(this.patientsService.getAll());
      this.patients = result ?? [];
    } catch (err) {
      console.error('Failed to load patients:', err);
    }
  }

  async addPatient() {
    if (!this.newPatient.patientName || !this.newPatient.patientPhone) return;
    try {
      await firstValueFrom(this.patientsService.add(this.newPatient));
      this.newPatient = { patientName: '', patientPhone: '' };
      this.loadPatients();
    } catch (err) {
      console.error('Failed to add patient:', err);
    }
  }

  async updatePatient(patient: Patient) {
    if (!patient.patientId) return;
    try {
      await firstValueFrom(this.patientsService.update(patient));
      this.loadPatients();
    } catch (err) {
      console.error('Failed to update patient:', err);
    }
  }

  async deletePatient(id: number) {
    try {
      await firstValueFrom(this.patientsService.delete(id));
      this.loadPatients();
    } catch (err) {
      console.error('Failed to delete patient:', err);
    }
  }
}
