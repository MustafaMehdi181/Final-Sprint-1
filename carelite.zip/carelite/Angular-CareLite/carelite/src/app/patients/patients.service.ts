// src/app/patients/patients.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Patient {
  patientId?: number;
  patientName: string;
  patientPhone: string;
}

@Injectable({ providedIn: 'root' })
export class PatientsService {
  private apiUrl = 'https://localhost:5001/api/Patients';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Patient[]> {
    return this.http.get<Patient[]>(this.apiUrl);
  }

  add(patient: Patient): Observable<any> {
    return this.http.post(this.apiUrl, patient);
  }

  update(patient: Patient): Observable<any> {
    return this.http.put(`${this.apiUrl}/${patient.patientId}`, patient);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
