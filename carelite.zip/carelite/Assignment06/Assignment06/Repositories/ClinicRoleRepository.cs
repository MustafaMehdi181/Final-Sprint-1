﻿using System.Data.SqlClient;
using Assignment06.Models;

namespace Assignment06.Repositories
{
    public class ClinicRoleRepository : IClinicRoleRepository
    {
        private readonly string _connectionString;

        public ClinicRoleRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<ClinicRole>> GetAllAsync()
        {
            var roles = new List<ClinicRole>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM ClinicRoles", conn);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    roles.Add(new ClinicRole
                    {
                        RoleId = (int)reader["RoleId"],
                        RoleName = reader["RoleName"].ToString()
                    });
                }
            }
            return roles;
        }

        public async Task AddAsync(ClinicRole role)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO ClinicRoles (RoleName) VALUES (@RoleName)", conn);
                cmd.Parameters.AddWithValue("@RoleName", role.RoleName);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task DeleteAsync(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM ClinicRoles WHERE RoleId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}
