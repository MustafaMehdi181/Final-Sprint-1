﻿using Assignment06.Models;

public interface IClinicRoleRepository
{
    Task<IEnumerable<ClinicRole>> GetAllAsync();
    Task AddAsync(ClinicRole role);
    Task DeleteAsync(int id);
}
