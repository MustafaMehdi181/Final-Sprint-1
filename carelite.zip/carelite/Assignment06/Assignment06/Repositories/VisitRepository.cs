﻿using System.Data.SqlClient;
using Assignment06.Models;

namespace Assignment06.Repositories
{
    public class VisitRepository : IVisitRepository
    {
        private readonly string _connectionString;

        public VisitRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<Visit>> GetAllAsync()
        {
            var visits = new List<Visit>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Visits", conn);
                await conn.OpenAsync();
                SqlDataReader reader = await cmd.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    visits.Add(new Visit
                    {
                        VisitId = (int)reader["VisitId"],
                        PatientId = (int)reader["PatientId"],
                        DoctorId = (int)reader["DoctorId"],
                        VisitTypeId = (int)reader["VisitTypeId"],
                        Duration = (int)reader["Duration"],
                        VisitDate = (DateTime)reader["VisitDate"],
                        DoctorNotes = reader["DoctorNotes"] == DBNull.Value ? null : reader["DoctorNotes"].ToString()
                    });
                }
            }
            return visits;
        }

        public async Task AddAsync(Visit visit)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    @"INSERT INTO Visits (PatientId, DoctorId, VisitTypeId, Duration, VisitDate, DoctorNotes) 
                      VALUES (@PatientId, @DoctorId, @VisitTypeId, @Duration, @VisitDate, @DoctorNotes)", conn);

                cmd.Parameters.AddWithValue("@PatientId", visit.PatientId);
                cmd.Parameters.AddWithValue("@DoctorId", visit.DoctorId);
                cmd.Parameters.AddWithValue("@VisitTypeId", visit.VisitTypeId);
                cmd.Parameters.AddWithValue("@Duration", visit.Duration);
                cmd.Parameters.AddWithValue("@VisitDate", visit.VisitDate);
                cmd.Parameters.AddWithValue("@DoctorNotes", (object?)visit.DoctorNotes ?? DBNull.Value);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task UpdateAsync(Visit visit)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    @"UPDATE Visits 
                      SET PatientId = @PatientId, DoctorId = @DoctorId, VisitTypeId = @VisitTypeId, 
                          Duration = @Duration, VisitDate = @VisitDate, DoctorNotes = @DoctorNotes
                      WHERE VisitId = @VisitId", conn);

                cmd.Parameters.AddWithValue("@VisitId", visit.VisitId);
                cmd.Parameters.AddWithValue("@PatientId", visit.PatientId);
                cmd.Parameters.AddWithValue("@DoctorId", visit.DoctorId);
                cmd.Parameters.AddWithValue("@VisitTypeId", visit.VisitTypeId);
                cmd.Parameters.AddWithValue("@Duration", visit.Duration);
                cmd.Parameters.AddWithValue("@VisitDate", visit.VisitDate);
                cmd.Parameters.AddWithValue("@DoctorNotes", (object?)visit.DoctorNotes ?? DBNull.Value);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task DeleteAsync(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Visits WHERE VisitId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);

                await conn.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}
