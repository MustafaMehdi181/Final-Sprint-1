﻿using Assignment06.Models;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;




//hasing -----------------------------------------


namespace Assignment06.Repositories
{
    public interface ILoginRepository
    {
        Task RegisterAsync(LoginModel login);
        Task<bool> ValidateUserAsync(string email, string password);
    }

    public class LoginRepository : ILoginRepository
    {
        private readonly string _connectionString;

        public LoginRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task RegisterAsync(LoginModel login)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "INSERT INTO Login (email, passwords) VALUES (@Email, @Passwords)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", login.Email);
                cmd.Parameters.AddWithValue("@Passwords", login.Passwords);

                await cmd.ExecuteNonQueryAsync();
            }
        }

        public async Task<bool> ValidateUserAsync(string email, string password)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                await conn.OpenAsync();
                string query = "SELECT COUNT(*) FROM Login WHERE email = @Email AND passwords = @Passwords";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Passwords", password);

                int count = (int)await cmd.ExecuteScalarAsync();
                return count > 0;
            }
        }
    }
}
