﻿using Assignment06.Models;

public interface IVisitRepository
{
    Task<IEnumerable<Visit>> GetAllAsync();
    Task AddAsync(Visit visit);
    Task UpdateAsync(Visit visit);
    Task DeleteAsync(int id);
}
