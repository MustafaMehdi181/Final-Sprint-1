﻿namespace Assignment06.Models
{
    public class ClinicRole
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
