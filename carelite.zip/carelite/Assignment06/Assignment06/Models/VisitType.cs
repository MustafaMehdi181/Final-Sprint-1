﻿namespace Assignment06.Models
{
    public class VisitType
    {
        public int VisitTypeId { get; set; }
        public string VisitTypeName { get; set; }
        public decimal Fee { get; set; }
    }
}
