﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClinicRolesController : ControllerBase
    {
        private readonly ClinicRoleService _service;

        public ClinicRolesController(ClinicRoleService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClinicRole>>> GetAll()
        {
            var roles = await _service.GetAllAsync();
            return Ok(roles);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] ClinicRole role)
        {
            if (role == null || string.IsNullOrWhiteSpace(role.RoleName))
                return BadRequest("Role name is required.");

            await _service.AddAsync(role);
            return Ok(new { Message = "Role added successfully" });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Role deleted successfully" });
        }
    }
}
