﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;
using Microsoft.AspNetCore.Authorization;

namespace Assignment06.Controllers
{
    [ApiController]
    [AllowAnonymous]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly PatientService _service;

        public PatientsController(PatientService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Patient>>> GetAll()
        {
            var patients = await _service.GetAllAsync();
            return Ok(patients);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Patient>> GetById(int id)
        {
            var patient = await _service.GetByIdAsync(id);
            if (patient == null)
                return NotFound(new { Message = $"Patient with ID {id} not found." });

            return Ok(patient);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Patient patient)
        {
            if (patient == null || string.IsNullOrWhiteSpace(patient.PatientName))
                return BadRequest("Patient name is required.");
            if (string.IsNullOrWhiteSpace(patient.PatientPhone))
                return BadRequest("Patient phone is required.");

            await _service.AddAsync(patient);
            return Ok(new { Message = "Patient added successfully" });
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Patient patient)
        {
            if (id != patient.PatientId)
                return BadRequest("Patient ID mismatch.");

            await _service.UpdateAsync(patient);
            return Ok(new { Message = "Patient updated successfully" });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Patient deleted successfully" });
        }
    }
}
