﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;
using Microsoft.AspNetCore.Authorization;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DoctorsController : ControllerBase
    {
        private readonly DoctorService _service;

        public DoctorsController(DoctorService service)
        {
            _service = service;
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<Doctor>>> GetAll()
        {
            var doctors = await _service.GetAllAsync();
            return Ok(doctors);
        }

        [HttpGet("{id}")]
        [AllowAnonymous]
        public async Task<ActionResult<Doctor>> GetById(int id)
        {
            var doctor = await _service.GetByIdAsync(id);
            if (doctor == null) return NotFound(new { Message = $"Doctor with ID {id} not found." });
            return Ok(doctor);
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Add([FromBody] Doctor doctor)
        {
            if (doctor == null || string.IsNullOrWhiteSpace(doctor.DoctorName))
                return BadRequest("Doctor name is required.");
            if (string.IsNullOrWhiteSpace(doctor.DoctorSpecialty))
                return BadRequest("Doctor specialty is required.");

            await _service.AddAsync(doctor);
            return Ok(new { Message = "Doctor added successfully" });
        }

        [HttpPut("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> Update(int id, [FromBody] Doctor doctor)
        {
            if (id != doctor.DoctorId)
                return BadRequest("Doctor ID mismatch.");

            await _service.UpdateAsync(doctor);
            return Ok(new { Message = "Doctor updated successfully" });
        }

        [HttpDelete("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Doctor deleted successfully" });
        }
    }
}
