﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;
using Microsoft.AspNetCore.Authorization;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class VisitsController : ControllerBase
    {
        private readonly VisitService _service;

        public VisitsController(VisitService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var visits = await _service.GetAllAsync();
            return Ok(visits);
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Visit visit)
        {
            if (visit == null) return BadRequest("Visit data is required.");

            await _service.AddAsync(visit);
            return Ok(new { Message = "Visit added successfully." });
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Visit visit)
        {
            if (visit == null || id != visit.VisitId)
                return BadRequest("Visit ID mismatch or missing data.");

            await _service.UpdateAsync(visit);
            return Ok(new { Message = "Visit updated successfully." });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Visit deleted successfully." });
        }
    }
}
