﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class VisitTypeService
    {
        private readonly IVisitTypeRepository _repository;

        public VisitTypeService(IVisitTypeRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<VisitType>> GetAllAsync() => await _repository.GetAllAsync();

        public async Task AddAsync(VisitType visitType) => await _repository.AddAsync(visitType);
    }
}
