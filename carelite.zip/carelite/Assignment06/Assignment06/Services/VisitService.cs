﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class VisitService
    {
        private readonly IVisitRepository _repository;

        public VisitService(IVisitRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Visit>> GetAllAsync() => await _repository.GetAllAsync();

        public async Task AddAsync(Visit visit) => await _repository.AddAsync(visit);

        public async Task UpdateAsync(Visit visit) => await _repository.UpdateAsync(visit);

        public async Task DeleteAsync(int id) => await _repository.DeleteAsync(id);
    }
}
