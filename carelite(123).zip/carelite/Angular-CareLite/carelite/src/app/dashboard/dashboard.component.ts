import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [RouterModule],
  template: `
    <h2>Dashboard</h2>
    <button type="button" [routerLink]="['/doctor']">Doctor Details</button>
    <button type="button" [routerLink]="['/patients']">Patient Details</button>
    <button type="button" [routerLink]="['/visits']">Visit Details</button>
    <button type="button" [routerLink]="['/visittypes']">Visit Types</button>
    <button type="button" [routerLink]="['/bill']">Billing</button>
  `,
  styles: [`
    h2 { margin-bottom: 20px; }
    button { margin: 10px; padding: 10px 20px; }
  `]
})
export class DashboardComponent {
  goTo(section: string) {
    console.log(`Navigating to ${section} details`);
    // Later we can navigate to child routes like /dashboard/doctor
  }
}
