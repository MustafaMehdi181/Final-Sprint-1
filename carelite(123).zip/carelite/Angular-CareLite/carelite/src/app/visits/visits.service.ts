import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Appointment {
  appointmentId?: number;
  doctorName: string;
  patientName: string;
  visitId: number;
  startTime: string;   // formatted local string "yyyy-MM-ddTHH:mm:ss"
  duration: number;
  fee: number;
  billStatus: string;
  clinicRoomNumber: string;
}

@Injectable({
  providedIn: 'root',
})
export class VisitsService {
  private apiUrl = 'https://localhost:5001/api/Appointment';

  constructor(private http: HttpClient) {}

  getAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(this.apiUrl);
  }

  addAppointment(appointment: Appointment): Observable<any> {
    return this.http.post(this.apiUrl, appointment);
  }

  updateAppointment(appointment: Appointment): Observable<any> {
    return this.http.put(`${this.apiUrl}/${appointment.appointmentId}`, appointment);
  }

  deleteAppointment(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
