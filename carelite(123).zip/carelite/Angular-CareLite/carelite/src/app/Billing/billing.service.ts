import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Bill {
  appointmentId: number;
  doctorName: string;
  patientName: string;
  startTime: string;
  duration: number;
  fee: number;
  clinicRoomNumber: string;
  billStatus: string;
}

@Injectable({
  providedIn: 'root'
})
export class BillingService {
  private apiUrl = 'https://localhost:5001/api/Billing';

  constructor(private http: HttpClient) {}

  // Get all unpaid bills
  getUnpaidBills(): Observable<Bill[]> {
    return this.http.get<Bill[]>(`${this.apiUrl}/unpaid`);
  }

  // Get bill by appointment id
  getBillByAppointmentId(id: number): Observable<Bill> {
    return this.http.get<Bill>(`${this.apiUrl}/${id}`);
  }

  // Mark a bill as paid
markBillAsPaid(id: number): Observable<string> {
  return this.http.put(`${this.apiUrl}/${id}/pay`, {}, { responseType: 'text' });
}


}
