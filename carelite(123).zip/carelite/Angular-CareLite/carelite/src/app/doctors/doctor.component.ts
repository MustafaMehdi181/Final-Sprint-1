import { Component, OnInit } from '@angular/core';
import { DoctorsService , Doctor } from './doctor.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-doctors',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './doctor.component.html'
})
export class DoctorsComponent implements OnInit {
  doctors: Doctor[] = [];
  filteredDoctors: Doctor[] = [];
  newDoctor: Doctor = { doctorName: '', doctorSpecialty: '' };
  searchTerm: string = '';

  constructor(private doctorService: DoctorsService) {}

  ngOnInit() {
    this.loadDoctors();
  }

  async loadDoctors() {
    try {
      const result = await firstValueFrom(this.doctorService.getAll());
      this.doctors = result ?? [];
      this.filteredDoctors = this.doctors; // start with all
    } catch (err) {
      console.error('Failed to load doctors:', err);
    }
  }

  searchDoctors() {
    if (!this.searchTerm.trim()) {
      this.filteredDoctors = this.doctors;
    } else {
      const term = this.searchTerm.toLowerCase();
      this.filteredDoctors = this.doctors.filter(d =>
        d.doctorName.toLowerCase().includes(term) ||
        d.doctorSpecialty.toLowerCase().includes(term)
      );
    }
  }

  // keep add/update/delete same but refresh filteredDoctors after changes
  async addDoctor() {
    if (!this.newDoctor.doctorName || !this.newDoctor.doctorSpecialty) return;
    try {
      await firstValueFrom(this.doctorService.add(this.newDoctor));
      this.newDoctor = { doctorName: '', doctorSpecialty: '' };
      await this.loadDoctors();
      this.searchDoctors(); // reapply filter
    } catch (err) {
      console.error('Failed to add doctor:', err);
    }
  }

  async updateDoctor(doc: Doctor) {
    if (!doc.doctorId) return;
    try {
      await firstValueFrom(this.doctorService.update(doc));
      await this.loadDoctors();
      this.searchDoctors();
    } catch (err) {
      console.error('Failed to update doctor:', err);
    }
  }

  async deleteDoctor(id: number) {
    try {
      await firstValueFrom(this.doctorService.delete(id));
      await this.loadDoctors();
      this.searchDoctors();
    } catch (err) {
      console.error('Failed to delete doctor:', err);
    }
  }
}
