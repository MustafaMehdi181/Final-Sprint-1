import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VisitTypeService , VisitType } from './visit-types.services';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-visit-types',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './visit-type.html'
})
export class VisitTypeComponent implements OnInit {
  visitTypes: VisitType[] = [];
  newVisitType: VisitType = { visitTypeName: '', fee: 0 };

  constructor(private visitTypeService: VisitTypeService) {}

  ngOnInit() {
    this.loadVisitTypes();
  }

  async loadVisitTypes() {
    try {
      const result = await firstValueFrom(this.visitTypeService.getAll());
      this.visitTypes = result ?? [];
    } catch (err) {
      console.error('Failed to load visit types:', err);
    }
  }

  async addVisitType() {
    if (!this.newVisitType.visitTypeName || this.newVisitType.fee == null) return;
    try {
      await firstValueFrom(this.visitTypeService.add(this.newVisitType));
      this.newVisitType = { visitTypeName: '', fee: 0 };
      this.loadVisitTypes();
    } catch (err) {
      console.error('Failed to add visit type:', err);
    }
  }

  async updateVisitType(vt: VisitType) {
    if (!vt.visitTypeId) return;
    try {
      await firstValueFrom(this.visitTypeService.update(vt));
      this.loadVisitTypes();
    } catch (err) {
      console.error('Failed to update visit type:', err);
    }
  }

  async deleteVisitType(id: number) {
    try {
      await firstValueFrom(this.visitTypeService.delete(id));
      this.loadVisitTypes();
    } catch (err) {
      console.error('Failed to delete visit type:', err);
    }
  }
}
