import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface VisitType {
  visitTypeId?: number;
  visitTypeName: string;
  fee: number;
}

@Injectable({ providedIn: 'root' })
export class VisitTypeService {
  private apiUrl = 'https://localhost:5001/api/VisitTypes';

  constructor(private http: HttpClient) {}

  getAll(): Observable<VisitType[]> {
    return this.http.get<VisitType[]>(this.apiUrl);
  }

  add(visitType: VisitType): Observable<any> {
    return this.http.post(this.apiUrl, visitType);
  }

  update(visitType: VisitType): Observable<any> {
    return this.http.put(`${this.apiUrl}/${visitType.visitTypeId}`, visitType);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
