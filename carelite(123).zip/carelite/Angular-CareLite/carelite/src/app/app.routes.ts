import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './auth/auth.guard';
import { DoctorsComponent } from './doctors/doctor.component';
import { PatientsComponent } from './patients/patients.component';
import { VisitsComponent } from './visits/visits.component';
import { VisitTypeComponent } from './visit-types/visit-types.components';
import { BillingComponent } from './Billing/billing.coponent';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'doctor' , component: DoctorsComponent},
  {path : 'patients' , component:PatientsComponent},
  {path: 'visits' , component: VisitsComponent , canActivate: [AuthGuard]},
  {path: 'visittypes' , component: VisitTypeComponent , canActivate: [AuthGuard]},
  {path: 'bill' , component: BillingComponent}

];
