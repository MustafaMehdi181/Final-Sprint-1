import { Component, OnInit } from '@angular/core';
import { PatientsService, Patient } from './patients.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-patients',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './patient.component.html'
})
export class PatientsComponent implements OnInit {
  patients: Patient[] = [];        // all patients
  filteredPatients: Patient[] = []; // displayed patients
  newPatient: Patient = { patientName: '', patientPhone: '' };
  searchTerm: string = '';          // search input binding

  constructor(private patientsService: PatientsService) {}

  ngOnInit() {
    this.loadPatients();
  }

  async loadPatients() {
    try {
      const result = await firstValueFrom(this.patientsService.getAll());
      this.patients = result ?? [];
      this.applyFilter(); // initialize filtered list
    } catch (err) {
      console.error('Failed to load patients:', err);
    }
  }

  async addPatient() {
    if (!this.newPatient.patientName || !this.newPatient.patientPhone) return;
    try {
      await firstValueFrom(this.patientsService.add(this.newPatient));
      this.newPatient = { patientName: '', patientPhone: '' };
      this.loadPatients();
    } catch (err) {
      console.error('Failed to add patient:', err);
    }
  }

  async updatePatient(patient: Patient) {
    if (!patient.patientId) return;
    try {
      await firstValueFrom(this.patientsService.update(patient));
      this.loadPatients();
    } catch (err) {
      console.error('Failed to update patient:', err);
    }
  }

  async deletePatient(id: number) {
    try {
      await firstValueFrom(this.patientsService.delete(id));
      this.loadPatients();
    } catch (err) {
      console.error('Failed to delete patient:', err);
    }
  }

  // 🔍 filter patients by search term
  applyFilter() {
    const term = this.searchTerm.toLowerCase();
    this.filteredPatients = this.patients.filter(
      p =>
        p.patientName.toLowerCase().includes(term) ||
        p.patientPhone.toLowerCase().includes(term)
    );
  }
}
