﻿using Assignment06.Models;

public interface IVisitTypeRepository
{
    Task<IEnumerable<VisitType>> GetAllAsync();
    Task AddAsync(VisitType visitType);
}
