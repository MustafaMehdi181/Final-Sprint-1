﻿using Assignment06.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Assignment06.Repositories
{
    public class AppointmentRepository
    {
        private readonly string _connectionString;

        public AppointmentRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<AppointmentInfo> GetAll()
        {
            var appointments = new List<AppointmentInfo>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * FROM AppointmentInfo";
                SqlCommand cmd = new SqlCommand(sql, conn);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    appointments.Add(MapReaderToAppointment(reader));
                }
            }

            return appointments;
        }

        public AppointmentInfo? GetById(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * FROM AppointmentInfo WHERE AppointmentId = @Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                    return MapReaderToAppointment(reader);
            }
            return null;
        }

        public int Add(AppointmentInfo appointment)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sql = @"INSERT INTO AppointmentInfo
                               (DoctorName, PatientName, VisitId, StartTime, Duration, Fee, BillStatus, ClinicRoomNumber)
                               OUTPUT INSERTED.AppointmentId
                               VALUES (@DoctorName, @PatientName, @VisitId, @StartTime, @Duration, @Fee, @BillStatus, @ClinicRoomNumber)";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@DoctorName", appointment.DoctorName);
                cmd.Parameters.AddWithValue("@PatientName", appointment.PatientName);
                cmd.Parameters.AddWithValue("@VisitId", appointment.VisitId);
                cmd.Parameters.AddWithValue("@StartTime", appointment.StartTime);
                cmd.Parameters.AddWithValue("@Duration", appointment.Duration);
                cmd.Parameters.AddWithValue("@Fee", appointment.Fee);
                cmd.Parameters.AddWithValue("@BillStatus", appointment.BillStatus ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ClinicRoomNumber", appointment.ClinicRoomNumber ?? (object)DBNull.Value);

                conn.Open();
                return (int)cmd.ExecuteScalar();
            }
        }

        public bool Update(AppointmentInfo appointment)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sql = @"UPDATE AppointmentInfo
                               SET DoctorName = @DoctorName,
                                   PatientName = @PatientName,
                                   VisitId = @VisitId,
                                   StartTime = @StartTime,
                                   Duration = @Duration,
                                   Fee = @Fee,
                                   BillStatus = @BillStatus,
                                   ClinicRoomNumber = @ClinicRoomNumber
                               WHERE AppointmentId = @Id";

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@DoctorName", appointment.DoctorName);
                cmd.Parameters.AddWithValue("@PatientName", appointment.PatientName);
                cmd.Parameters.AddWithValue("@VisitId", appointment.VisitId);
                cmd.Parameters.AddWithValue("@StartTime", appointment.StartTime);
                cmd.Parameters.AddWithValue("@Duration", appointment.Duration);
                cmd.Parameters.AddWithValue("@Fee", appointment.Fee);
                cmd.Parameters.AddWithValue("@BillStatus", appointment.BillStatus ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ClinicRoomNumber", appointment.ClinicRoomNumber ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Id", appointment.AppointmentId);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool Delete(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                string sql = "DELETE FROM AppointmentInfo WHERE AppointmentId = @Id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        private AppointmentInfo MapReaderToAppointment(SqlDataReader reader)
        {
            return new AppointmentInfo
            {
                AppointmentId = Convert.ToInt32(reader["AppointmentId"]),
                DoctorName = reader["DoctorName"].ToString(),
                PatientName = reader["PatientName"].ToString(),
                VisitId = Convert.ToInt32(reader["VisitId"]),
                StartTime = Convert.ToDateTime(reader["StartTime"]),
                Duration = Convert.ToInt32(reader["Duration"]),
                Fee = Convert.ToDecimal(reader["Fee"]),
                BillStatus = reader["BillStatus"].ToString(),
                ClinicRoomNumber = reader["ClinicRoomNumber"].ToString()
            };
        }
    }
}
