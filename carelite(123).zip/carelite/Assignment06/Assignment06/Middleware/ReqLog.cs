﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using Assignment06.Repositories;
using Assignment06.Models;

namespace Assignment06.Middleware
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context, ApiLogRepository logRepo)
        {
            string userName = context.User.Identity?.IsAuthenticated == true
                ? context.User.FindFirst(ClaimTypes.Name)?.Value ?? "Unknown"
                : "Anonymous";

            string method = context.Request.Method;
            string path = context.Request.Path;

            await _next(context); // let request continue

            int statusCode = context.Response.StatusCode;
            bool success = statusCode >= 200 && statusCode < 300;

            var log = new ApiLog
            {
                UserName = userName,
                HttpMethod = method,
                RequestPath = path,
                StatusCode = statusCode,
                Success = success,
                Timestamp = DateTime.Now
            };

            await logRepo.AddLogAsync(log);
        }
    }

    // Extension method
    public static class RequestLoggingMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestLoggingMiddleware>();
        }
    }
}
