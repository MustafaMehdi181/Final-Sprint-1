﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class ClinicRoleService
    {
        private readonly IClinicRoleRepository _repository;

        public ClinicRoleService(IClinicRoleRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<ClinicRole>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task AddAsync(ClinicRole role)
        {
            await _repository.AddAsync(role);
        }

        public async Task DeleteAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}
