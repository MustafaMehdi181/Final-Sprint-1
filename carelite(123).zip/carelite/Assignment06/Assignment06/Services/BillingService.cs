﻿using Assignment06.Models;
using Assignment06.Repositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment06.Services
{
    public class BillingService
    {
        private readonly AppointmentRepository _appointmentRepo;

        public BillingService(AppointmentRepository appointmentRepo)
        {
            _appointmentRepo = appointmentRepo;
        }

        // Get all unpaid bills (Pending OR Unpaid)
        public Task<IEnumerable<Bill>> GetUnpaidBillsAsync()
        {
            return Task.Run(() =>
            {
                var appointments = _appointmentRepo.GetAll();
                return appointments
                    .Where(a => a.BillStatus != null &&
                               (a.BillStatus.Equals("pending", System.StringComparison.OrdinalIgnoreCase) ||
                                a.BillStatus.Equals("unpaid", System.StringComparison.OrdinalIgnoreCase)))
                    .Select(a => new Bill
                    {
                        AppointmentId = a.AppointmentId,
                        DoctorName = a.DoctorName,
                        PatientName = a.PatientName,
                        StartTime = a.StartTime,
                        Duration = a.Duration,
                        Fee = a.Fee,
                        ClinicRoomNumber = a.ClinicRoomNumber,
                        BillStatus = a.BillStatus
                    });
            });
        }

        // Get a single unpaid bill by appointment ID (Pending OR Unpaid)
        public Task<Bill?> GetBillByAppointmentIdAsync(int appointmentId)
        {
            return Task.Run(() =>
            {
                var appointment = _appointmentRepo.GetById(appointmentId);
                if (appointment == null ||
                    appointment.BillStatus == null ||
                    !(appointment.BillStatus.Equals("pending", System.StringComparison.OrdinalIgnoreCase) ||
                      appointment.BillStatus.Equals("unpaid", System.StringComparison.OrdinalIgnoreCase)))
                    return null;

                return new Bill
                {
                    AppointmentId = appointment.AppointmentId,
                    DoctorName = appointment.DoctorName,
                    PatientName = appointment.PatientName,
                    StartTime = appointment.StartTime,
                    Duration = appointment.Duration,
                    Fee = appointment.Fee,
                    ClinicRoomNumber = appointment.ClinicRoomNumber,
                    BillStatus = appointment.BillStatus
                };
            });
        }

        // Mark a bill as paid (only if Pending OR Unpaid)
        public Task<bool> MarkBillAsPaidAsync(int appointmentId)
        {
            return Task.Run(() =>
            {
                var appointment = _appointmentRepo.GetById(appointmentId);
                if (appointment == null ||
                    appointment.BillStatus == null ||
                    !(appointment.BillStatus.Equals("pending", System.StringComparison.OrdinalIgnoreCase) ||
                      appointment.BillStatus.Equals("unpaid", System.StringComparison.OrdinalIgnoreCase)))
                    return false;

                appointment.BillStatus = "Paid";
                _appointmentRepo.Update(appointment);
                return true;
            });
        }
    }
}
