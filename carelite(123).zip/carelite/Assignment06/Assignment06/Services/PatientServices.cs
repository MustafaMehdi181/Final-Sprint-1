﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class PatientService
    {
        private readonly IPatientRepository _repository;

        public PatientService(IPatientRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Patient>> GetAllAsync() => await _repository.GetAllAsync();

        public async Task<Patient?> GetByIdAsync(int id) => await _repository.GetByIdAsync(id);

        public async Task AddAsync(Patient patient) => await _repository.AddAsync(patient);

        public async Task UpdateAsync(Patient patient) => await _repository.UpdateAsync(patient);

        public async Task DeleteAsync(int id) => await _repository.DeleteAsync(id);
    }
}
