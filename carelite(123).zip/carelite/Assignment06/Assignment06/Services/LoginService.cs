﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public interface ILoginService
    {
        Task RegisterAsync(LoginModel login);
        Task<bool> ValidateUserAsync(string email, string password);
    }

    public class LoginService : ILoginService
    {
        private readonly ILoginRepository _repository;

        public LoginService(ILoginRepository repository)
        {
            _repository = repository;
        }

        public async Task RegisterAsync(LoginModel login)
        {
            await _repository.RegisterAsync(login);
        }

        public async Task<bool> ValidateUserAsync(string email, string password)
        {
            return await _repository.ValidateUserAsync(email, password);
        }
    }
}
