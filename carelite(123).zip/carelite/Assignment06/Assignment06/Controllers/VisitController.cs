﻿using Assignment06.Models;
using Assignment06.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class AppointmentController : ControllerBase
    {
        private readonly AppointmentService _service;

        public AppointmentController(AppointmentService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(_service.GetAllAppointments());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var appointment = _service.GetAppointmentById(id);
            if (appointment == null)
                return NotFound();
            return Ok(appointment);
        }

        [HttpPost]
        public IActionResult Create([FromBody] AppointmentInfo appointment)
        {
            try
            {
                int newId = _service.CreateAppointment(appointment);
                return Ok(new { message = "Appointment created successfully.", appointmentId = newId });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] AppointmentInfo appointment)
        {
            try
            {
                appointment.AppointmentId = id;
                bool updated = _service.UpdateAppointment(appointment);

                if (!updated)
                    return NotFound("Appointment not found.");
                return Ok(new { message = "Appointment updated successfully." });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                bool deleted = _service.DeleteAppointment(id);
                if (!deleted)
                    return NotFound("Appointment not found.");
                return Ok(new { message = "Appointment deleted successfully." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}
