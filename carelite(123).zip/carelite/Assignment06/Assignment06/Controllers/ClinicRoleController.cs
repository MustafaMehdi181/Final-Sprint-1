﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClinicRolesController : ControllerBase
    {
        private readonly ClinicRoleService _service;

        public ClinicRolesController(ClinicRoleService service)
        {
            _service = service;
        }

        // GET: api/ClinicRoles
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClinicRole>>> GetAll()
        {
            var roles = await _service.GetAllAsync();
            return Ok(roles);
        }

        // POST: api/ClinicRoles
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] ClinicRole role)
        {
            if (!ModelState.IsValid) // ✅ uses validation attributes from the model
                return BadRequest(ModelState);

            await _service.AddAsync(role);
            return CreatedAtAction(nameof(GetAll), new { id = role.RoleId }, role);
        }

        // DELETE: api/ClinicRoles/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Role deleted successfully" });
        }
    }
}
