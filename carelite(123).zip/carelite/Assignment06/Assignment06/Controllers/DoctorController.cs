﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;
using Microsoft.AspNetCore.Authorization;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DoctorsController : ControllerBase
    {
        private readonly DoctorService _service;

        public DoctorsController(DoctorService service)
        {
            _service = service;
        }

        // GET: api/Doctors
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<Doctor>>> GetAll()
        {
            var doctors = await _service.GetAllAsync();
            return Ok(doctors);
        }

        // GET: api/Doctors/5
        [HttpGet("{id}")]
        [AllowAnonymous]
        public async Task<ActionResult<Doctor>> GetById(int id)
        {
            var doctor = await _service.GetByIdAsync(id);
            if (doctor == null)
                return NotFound(new { Message = $"Doctor with ID {id} not found." });

            return Ok(doctor);
        }

        // POST: api/Doctors
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Add([FromBody] Doctor doctor)
        {
            if (!ModelState.IsValid)  // ✅ uses attributes from Doctor model
                return BadRequest(ModelState);

            await _service.AddAsync(doctor);
            return CreatedAtAction(nameof(GetById), new { id = doctor.DoctorId }, doctor);
        }

        // PUT: api/Doctors/5
        [HttpPut("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> Update(int id, [FromBody] Doctor doctor)
        {
            if (id != doctor.DoctorId)
                return BadRequest("Doctor ID mismatch.");

            if (!ModelState.IsValid)  // ✅ validates again
                return BadRequest(ModelState);

            await _service.UpdateAsync(doctor);
            return Ok(new { Message = "Doctor updated successfully" });
        }

        // DELETE: api/Doctors/5
        [HttpDelete("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Doctor deleted successfully" });
        }
    }
}
