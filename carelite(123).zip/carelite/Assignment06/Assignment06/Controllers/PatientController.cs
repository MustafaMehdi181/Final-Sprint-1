﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;
using Microsoft.AspNetCore.Authorization;

namespace Assignment06.Controllers
{
    [ApiController]
    [AllowAnonymous]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly PatientService _service;

        public PatientsController(PatientService service)
        {
            _service = service;
        }

        // GET: api/Patients
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Patient>>> GetAll()
        {
            var patients = await _service.GetAllAsync();
            return Ok(patients);
        }

        // GET: api/Patients/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Patient>> GetById(int id)
        {
            var patient = await _service.GetByIdAsync(id);
            if (patient == null)
                return NotFound(new { Message = $"Patient with ID {id} not found." });

            return Ok(patient);
        }

        // POST: api/Patients
        [HttpPost]
        public async Task<IActionResult> Add([FromBody] Patient patient)
        {
            if (!ModelState.IsValid)  // ✅ Uses validation from Patient model
                return BadRequest(ModelState);

            await _service.AddAsync(patient);
            return CreatedAtAction(nameof(GetById), new { id = patient.PatientId }, patient);
        }

        // PUT: api/Patients/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Patient patient)
        {
            if (id != patient.PatientId)
                return BadRequest("Patient ID mismatch.");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            await _service.UpdateAsync(patient);
            return Ok(new { Message = "Patient updated successfully" });
        }

        // DELETE: api/Patients/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _service.DeleteAsync(id);
            return Ok(new { Message = "Patient deleted successfully" });
        }
    }
}
