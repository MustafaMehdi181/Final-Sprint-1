﻿using Assignment06.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BillingController : ControllerBase
    {
        private readonly BillingService _billingService;

        public BillingController(BillingService billingService)
        {
            _billingService = billingService;
        }

        [HttpGet("unpaid")]
        public async Task<IActionResult> GetUnpaidBills()
        {
            var bills = await _billingService.GetUnpaidBillsAsync();
            return Ok(bills);
        }

        [HttpGet("{appointmentId}")]
        public async Task<IActionResult> GetBill(int appointmentId)
        {
            var bill = await _billingService.GetBillByAppointmentIdAsync(appointmentId);
            if (bill == null) return NotFound("Bill not found or already paid.");
            return Ok(bill);
        }

        [HttpPut("{appointmentId}/pay")]
        public async Task<IActionResult> MarkBillAsPaid(int appointmentId)
        {
            var success = await _billingService.MarkBillAsPaidAsync(appointmentId);
            if (!success) return BadRequest("Bill not found or already paid.");
            return Ok("Bill marked as Paid successfully.");
        }
    }
}
