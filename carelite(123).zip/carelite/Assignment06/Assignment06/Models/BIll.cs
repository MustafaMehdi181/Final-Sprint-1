﻿namespace Assignment06.Models
{
    public class Bill
    {
        public int AppointmentId { get; set; }
        public string DoctorName { get; set; }
        public string PatientName { get; set; }
        public DateTime StartTime { get; set; }
        public int Duration { get; set; }
        public decimal Fee { get; set; }
        public string ClinicRoomNumber { get; set; }
        public string BillStatus { get; set; }
    }
}
