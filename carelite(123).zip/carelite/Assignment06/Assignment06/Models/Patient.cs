﻿using System.ComponentModel.DataAnnotations;

namespace Assignment06.Models
{
    public class Patient
    {
        public int PatientId { get; set; }

        [Required(ErrorMessage = "Patient name is required")]
        [MaxLength(100, ErrorMessage = "Patient name cannot exceed 100 characters")]
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^\d{10,15}$", ErrorMessage = "Phone must be 10–15 digits")]
        public string PatientPhone { get; set; }
    }
}
