﻿using System.ComponentModel.DataAnnotations;

namespace Assignment06.Models
{
    public class ClinicRole
    {
        public int RoleId { get; set; }

        [Required(ErrorMessage = "Role name is required")]
        [MaxLength(50, ErrorMessage = "Role name cannot exceed 50 characters")]
        public string RoleName { get; set; }
    }
}
