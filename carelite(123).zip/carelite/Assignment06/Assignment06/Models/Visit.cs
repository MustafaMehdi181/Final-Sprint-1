﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Assignment06.Models
{
    public class AppointmentInfo
    {
        public int AppointmentId { get; set; } // Auto-increment (but not PK in DB if you don’t want strict PKs)

        [Required]
        public string DoctorName { get; set; }

        [Required]
        public string PatientName { get; set; }

        public int VisitId { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Range(1, 480)]
        public int Duration { get; set; }

        [Range(0, double.MaxValue)]
        public decimal Fee { get; set; }

        [MaxLength(50)]
        public string BillStatus { get; set; } // e.g. "Paid", "Unpaid", "Pending"

        [MaxLength(10)]
        public string ClinicRoomNumber { get; set; }
    }
}
